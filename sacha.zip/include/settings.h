/*
** EPITECH PROJECT, 2024
** rpg
** File description:
** settings
*/

#ifndef SETTINGS_H_
    #define SETTINGS_H_
    #include "game.h"

//settings
void set_fps(game_t *game, int fps);


#endif /* !SETTINGS_H_ */

/*
** EPITECH PROJECT, 2024
** RPG
** File description:
** const
*/

#ifndef CONST_H_
    #define CONST_H_

    #define EPSILON 0.0000001
    #define PI 3.14159265358979323846
    #define HB_X 920
    #define UNUSED __attribute__((unused))

#endif /* !CONST_H_ */

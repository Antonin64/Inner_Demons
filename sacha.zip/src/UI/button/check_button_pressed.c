/*
** EPITECH PROJECT, 2024
** my_paint
** File description:
** check_button_pressed
*/

#include "button.h"
/*
void check_btn_pressed(sfRenderWindow *window, app_t *app)
{
    sfVector2f pos = get_mouse_pos(window);

    drop_menu_clicked(app->ui->file, pos, app);
    drop_menu_clicked(app->ui->tool, pos, app);
    drop_menu_clicked(app->ui->help, pos, app);
    if (is_button_pressed(app->ui->brush_options->circle_shape, pos))
        app->tool->brush_param->shape = CIRCLE;
    if (is_button_pressed(app->ui->brush_options->square_shape, pos))
        app->tool->brush_param->shape = SQUARE;
}

void check_btn_hover(sfRenderWindow *window, app_t *app)
{
    sfVector2f pos = get_mouse_pos(window);

    drop_menu_hover(app->ui->file, pos);
    drop_menu_hover(app->ui->tool, pos);
    drop_menu_hover(app->ui->help, pos);
}*/

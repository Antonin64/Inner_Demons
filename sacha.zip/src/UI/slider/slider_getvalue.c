/*
** EPITECH PROJECT, 2024
** my_paint
** File description:
** slider_getvalue
*/

#include "slider.h"

float slider_getvalue(slider_t *slider)
{
    return slider->value;
}

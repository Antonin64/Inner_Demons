/*
** EPITECH PROJECT, 2024
** rpg
** File description:
** create_vector
*/

#include "game.h"

sfVector2f v2f(float x, float y)
{
    return (sfVector2f){x, y};
}

sfVector2i v2i(int x, int y)
{
    return (sfVector2i){x, y};
}
